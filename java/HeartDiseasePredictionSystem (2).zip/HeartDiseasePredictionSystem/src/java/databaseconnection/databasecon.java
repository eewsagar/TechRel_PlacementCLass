package databaseconnection;
import java.sql.*;
import org.eclipse.jdt.internal.compiler.batch.Main;

public class databasecon
{
	static Connection con;
        public static void main(String[] args) {
        getconnection();
    }
	public static Connection getconnection()
	{
 		
 			
		try
		{
			Class.forName("com.mysql.jdbc.Driver");	
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cam","root","");
                        System.out.println("Connected");
		}
		catch(Exception e)
		{
			System.out.println("class error "+e.getMessage());
		}
		return con;
	}
        
	
}
