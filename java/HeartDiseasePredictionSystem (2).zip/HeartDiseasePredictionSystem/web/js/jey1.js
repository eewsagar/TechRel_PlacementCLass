

$(document).ready(function() {
	
	$("#log").click(function() 
			{
		
		if ($("#userid").val() == "")

		{
			alert("enter user name");
			$("#userid").focus();
			return false;
		}

		if ($("#pass").val() == "")

		{
			alert("enter password");
			$("#pass").focus();
			return false;
		}

		});
	

	});

$(document).ready(function() {
	
	$("#stalog").click(function() 
			{
		
		if ($("#userid").val() == "")

		{
			alert("enter user name");
			$("#userid").focus();
			return false;
		}

		if ($("#pass").val() == "")

		{
			alert("enter password");
			$("#pass").focus();
			return false;
		}

		});
	

	});

$(document).ready(function() {
	
	$("#prolog").click(function() 
			{
		
		if ($("#userid").val() == "")

		{
			alert("enter user name");
			$("#userid").focus();
			return false;
		}

		if ($("#pass").val() == "")

		{
			alert("enter password");
			$("#pass").focus();
			return false;
		}

		});
	

	});

$(document).ready(function() {
$("#signup").click(function() 
		{
	
	if ($("#name").val() == "")

	{
		alert("enter name");
		$("#name").focus();
		return false;
	}
	if ($("#userid").val() == "")

	{
		alert("enter user id");
		$("#userid").focus();
		return false;
	}

	if ($("#pass").val() == "")

	{
		alert("enter password");
		$("#pass").focus();
		return false;
	}
	if ($("#mobile").val() == "")

	{
		alert("enter mobile number");
		$("#mobile").focus();
		return false;
	}
	if ($("#email").val() == "")

	{
		alert("enter email id");
		$("#email").focus();
		return false;
	}

	if ($("#gender").val() == "")

	{
		alert("enter gender");
		$("#gender").focus();
		return false;
	}
	if ($("#age").val() == "")

	{
		alert("enter age");
		$("#age").focus();
		return false;
	}

	});
});


$(document).ready(function() {
	
	$("#amd").click(function() 
			{
		
		if ($("#title").val() == "")

		{
			alert("enter title name");
			$("#userid").focus();
			return false;
		}

		
		});
	

	});
