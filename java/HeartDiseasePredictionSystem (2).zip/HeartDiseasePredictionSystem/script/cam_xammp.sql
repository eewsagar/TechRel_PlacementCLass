DROP DATABASE IF EXISTS cam;
CREATE DATABASE  cam;
USE  cam;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cam`
--

-- --------------------------------------------------------

--
-- Table structure for table `graph`
--

CREATE TABLE `graph` (
  `gid` int(50) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `x` int(50) NOT NULL,
  `maximum_value` int(50) NOT NULL,
  `user_value` int(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `disc` varchar(255) NOT NULL
) ;

--
-- Dumping data for table `graph`
--

INSERT INTO `graph` (`gid`, `x`, `maximum_value`, `user_value`, `name`, `disc`) VALUES
(1, 30, 456, 120, 'covid', 'it is high');

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `name` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL
) ;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`name`, `user`, `pass`) VALUES
('provider', 'provider', 'provider'),
('sta', 'sta', 'sta');

-- --------------------------------------------------------

--
-- Table structure for table `medication`
--

CREATE TABLE `medication` (
  `mid` int(50) NOT NULL  PRIMARY KEY AUTO_INCREMENT,
  `tid` varchar(255) NOT NULL,
  `titname` varchar(255) NOT NULL,
  `minvaluess` varchar(255) DEFAULT NULL,
  `maxvaluess` varchar(255) DEFAULT NULL,
  `disc` varchar(255) NOT NULL
) ;

--
-- Dumping data for table `medication`
--

INSERT INTO `medication` (`mid`, `tid`, `titname`, `minvaluess`, `maxvaluess`, `disc`) VALUES
(1, 'ü´|“?‡¤Ôúé/ý', 'ƒøþ±Úé•\"¾`M\0à', 'KSì€”¾vfG­öé5e', ' •×g\0¥N´ÃK?è\\hìÆ', '7ÊeW ¤#sa¥ØësÞ');

-- --------------------------------------------------------

--
-- Table structure for table `newtitle`
--

CREATE TABLE `newtitle` (
  `tid` int(50) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `titname` varchar(255) NOT NULL
) ;

--
-- Dumping data for table `newtitle`
--

INSERT INTO `newtitle` (`tid`, `titname`) VALUES
(1, 'covid');

-- --------------------------------------------------------

--
-- Table structure for table `relatedposts`
--

CREATE TABLE `relatedposts` (
  `pid` int(50) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `mid` varchar(255) NOT NULL,
  `postby` varchar(255) NOT NULL,
  `comments` varchar(200) NOT NULL,
  `date` varchar(255) NOT NULL
) ;

--
-- Dumping data for table `relatedposts`
--

INSERT INTO `relatedposts` (`pid`, `mid`, `postby`, `comments`, `date`) VALUES
(1, 'ü´|“?‡¤Ôúé/ý', '.•Åæ8¶N|)‰‚AlZ,', 'ÉÅ\Z/ýÂf\'\'P•ºóºtgOîGºÃ€JÂþç¨ƒ»üP¢—`f˜ør³ æÚ:ó', 'zBÒTÜBÛªp_x\"Ñ6=;½y§çˆ¶EoIj×');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `uid` int(50) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `gen` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`uid`, `name`, `age`, `gen`, `user`, `pass`, `email`, `mobile`, `date`) VALUES
(1, 'nithiya', '23', 'male', 'nithiya', 'nithiya', 'nithiya@gmail.com', '7878878787', '09/09/2021');

-- --------------------------------------------------------

--
-- Table structure for table `token`
--

CREATE TABLE `token` (
  `tok_id` int(50) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `uid` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `query` varchar(255) NOT NULL,
  `qdate` varchar(255) NOT NULL
) ;

--
-- Dumping data for table `token`
--

INSERT INTO `token` (`tok_id`, `uid`, `name`, `token`, `query`, `qdate`) VALUES
(1, 'ü´|“?‡¤Ôúé/ý', 'cx=ñE£xyäšS‡èÀ€', '7ÛS¡“üµN0\\žÆ•xb', 'Vp§†``a|¯ÊÆàjS$ÐMPV0øµÅØy', '÷tPRÂyT8­Äå3(·ÖLˆÌ$ù |ùñGQ”‡”ýo');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  `age` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `userid` varchar(255) NOT NULL
) ;